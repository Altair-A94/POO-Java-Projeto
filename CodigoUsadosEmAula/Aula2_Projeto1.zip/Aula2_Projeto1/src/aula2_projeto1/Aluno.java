package aula2_projeto1;

public class Aluno {
//atributos(dados)
private int matricula;
private String nome;
private float cr;
//métodos
    
//construtor para criar objetos
public Aluno() {
 nome = "Annie";   
}
//metodo de acesso
public String getNome(){
    return nome;
}
}