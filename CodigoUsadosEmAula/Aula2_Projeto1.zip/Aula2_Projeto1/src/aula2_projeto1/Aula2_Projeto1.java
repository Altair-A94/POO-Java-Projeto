//Aula2-Projeto1 - teste
package aula2_projeto1;

public class Aula2_Projeto1 {

    //método prinipal de execução
    public static void main(String[] args) {
        //entrada de dados
        int x= 10;
        String email = "rrrr@xyz.com";
        Aluno a1, a2, a3; // declaração das variaveis
        //criar objeto
        a1 = new Aluno();
        a2 = new Aluno();
        a3 = new Aluno();
        //processamento
        x++ ;//alternativa para x = x + 1;
        // Exibir seu nome
        System.out.println("Waldir");
        System.out.println("Ciencias da Computação");
        System.out.println(x);
        System.out.println(a1.getNome());
        System.out.println(a2);
        System.out.println(a3);
    }//Fim do metodo
    
}//Fim da Classe
