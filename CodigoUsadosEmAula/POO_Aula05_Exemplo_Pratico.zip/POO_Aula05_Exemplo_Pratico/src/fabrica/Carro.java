package fabrica;

public class Carro {
    
private String modelo ;
//atributo motor
private Motor motor;

    public Carro() {
    }

    public Carro(String modelo, Motor motor) {
        this.modelo = modelo;
        this.motor = motor;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }

// metodo para obter a velocidade maxima do carro
    public float obterVelocidadeMaxima(){
    
    //definir a velocidade máxima
    float velocidade = 0;
    if (motor.getCilindrada() <= 1.0)
                velocidade = 140;
    else
        if (motor.getCilindrada() <= 1.6)
            velocidade = 180;
        else 
            if (motor.getCilindrada() <= 2.0)
             velocidade = 220;
               else
                  velocidade = 260;
    return velocidade ;
                
         
              
                        
    } //fim do metodo
@Override
public String toString(){
    return "Carro: modelo="+ modelo  +", motor=" + motor.getCilindrada()
            + ", velocidade maxima =" + obterVelocidadeMaxima();
}
}// fim da classe
