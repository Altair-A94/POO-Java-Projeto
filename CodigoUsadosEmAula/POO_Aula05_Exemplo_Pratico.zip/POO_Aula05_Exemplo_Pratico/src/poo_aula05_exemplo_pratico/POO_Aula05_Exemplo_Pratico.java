
package poo_aula05_exemplo_pratico;

import fabrica.Carro;
import fabrica.Motor;

public class POO_Aula05_Exemplo_Pratico {

    public static void main(String[] args) {
        //criar motores
        Motor m1 = new Motor() ;
        m1.setCilindrada(1.0F);
        Motor m2 = new Motor(2);
        
        //criar um carro
        Carro c1 = new Carro();
        c1.setModelo("Fiat Siena");
        c1.setMotor(m1);
        Carro c2 = new Carro("Chevrolet Onix", m2);
        
//        System.out.println("Carro 1: " + c1.getModelo() 
//                +" Cilindrada: "+ c1.getMotor().getCilindrada() 
//                + " Velociade Maxima: " 
//                + c1.obterVelocidadeMaxima());
//        System.out.println("Carro 2: " + c2.getModelo() 
//                +" Cilindrada: "+ c2.getMotor().getCilindrada() 
//                + " Velociade Maxima: " + c2.obterVelocidadeMaxima());
//        
        System.out.println(c1);
        System.out.println(c2);
    }
    
}
