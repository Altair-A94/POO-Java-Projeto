
package aula03_exemplo01;

public class Aula03_Exemplo01 {

    public static void main(String[] args) {
        //criar                 nome,endereço 
        Pessoa p1 = new Pessoa ("Ana","Rio de janeiro , 94");
      //  Pessoa p2 = new Pessoa();
        Funcionario f = new Funcionario(); 
        //alterar
        p1.setNome("Kolean");
        p1.setEndereco("Berlun,94");
        //funcionario
        f.setNome("Ely");
        f.setEndereco("Berlun,94");
        f.setMatricula(123);
        f.setSalario(1200);
        
           //exibição pessoa
        //System.out.println(p1.imprimir() + "\n" + p2.imprimir());
        // f.funcionario
        System.out.println(f.imprimir());
       
    }
    
}