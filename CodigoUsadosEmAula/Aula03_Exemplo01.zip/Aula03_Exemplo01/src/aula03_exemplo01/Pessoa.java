
package aula03_exemplo01;


public class Pessoa {
    //abributos
    private String nome,endereco;
    
    public Pessoa(){
        this.nome = "" ;
        this.endereco = "" ;
}
    //construtores
    public Pessoa(String nome, String endereco) {
        this.nome = nome;
        this.endereco = endereco;
       
    }
    //sets e gets (acesso)
    public String getEndereco() {
        return endereco;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    //imprimir
    
    public String imprimir(){ 
        return "Nome: " + nome + "\nEndereço: " + endereco;
    }
     
}
