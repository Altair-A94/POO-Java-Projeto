
package aula03_exemplo01;

public class Funcionario extends Pessoa {
    private int matricula;
    private float salario;
    
    public Funcionario(){
        super();
        this.matricula = 0;
        this.salario = 0;
    }
    public Funcionario(String nome ,String endereco ,int matricula ,float salario){
        //enviar para a superclasse
        super(nome,endereco);
        this.matricula = matricula;
        this.salario = salario;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }
    @Override
       public String imprimir(){ 
        return super.imprimir() + "\nmatricula: " + matricula + "\nSalarío: " + salario;
    }
    
    
    
    
    
    
}
