package modelo;

public class Carro extends Veiculo {
    private String tipo;
    

    public Carro() {
    }

    public Carro(String tipo) {
        this.tipo = tipo;
    }

    public Carro(String tipo, String modelo, int ano) {
        super(modelo, ano);
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    @Override
    public String imprimir(){
        
        return "Modelo: "+ getModelo() + "\nAno: "
                + getAno() + "\nTipo: " + tipo;
        
    }
    
    
                    
       
    
    }

