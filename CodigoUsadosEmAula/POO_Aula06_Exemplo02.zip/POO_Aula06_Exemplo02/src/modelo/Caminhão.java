
package modelo;

public class Caminhão extends Veiculo {
    private int eixos;

    public Caminhão() {
    }

    public Caminhão(int eixos) {
        this.eixos = eixos;
    }

    public Caminhão(int eixos, String modelo, int ano) {
        super(modelo, ano);
        this.eixos = eixos;
    }

    public int getEixos() {
        return eixos;
    }

    public void setEixos(int eixos) {
        this.eixos = eixos;
    }
    
    /**
     *
     * @return
     */
    @Override
    public String imprimir(){
        
        return "Modelo: "+ getModelo() + "\nEixos" + eixos;
    
    }

}

