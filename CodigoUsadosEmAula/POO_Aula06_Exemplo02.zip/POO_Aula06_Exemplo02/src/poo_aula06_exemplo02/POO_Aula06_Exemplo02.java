package poo_aula06_exemplo02;

import java.util.Scanner;
import modelo.Carro;
import modelo.Veiculo;

public class POO_Aula06_Exemplo02 {


    public static void main(String[] args) {
        
        
        //Entrada de dados
        Scanner teclado = new Scanner(System.in);
        System.out.print("Digite o modelo do carro: ");
        String m = teclado.next();
        System.out.print("Digite o ano do carro: ");
        int a = teclado.nextInt();
        System.out.print("Digite o tipo do carro: ");
        String t = teclado.next();
       //processamento
       Carro c = new Carro(t,m,a);
       //imprimir
       System.out.println(c.imprimir());
       if (c instanceof Veiculo)
       System.out.println("É um veiculo");
       else
       System.out.println("Não é um veiculo");
       
    }
    
}
