
package exercícios01_1;

import java.util.Scanner;


public class Exercícios01_1 {

   
    public static void main(String[] args) {
        //entrada de dados
        int n1,n2,soma,subtracao,mult,resto;
        float divisao;
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digite o Primeiro número:");
        n1 = teclado.nextInt();
        System.out.println("Digite o Segundo número:");
        n2 = teclado.nextInt();
        //processamento
        //soma
        soma = n1 + n2;
        subtracao = n1 - n2;
        divisao = n1 / n2;
        mult = n1 * n2;
        resto = n1 % n2;
        
        
        //saida de dados 
        System.out.println("soma:" + soma);
        System.out.println("subtração:" + subtracao);
        System.out.println("divisao:" + divisao);
        System.out.println("mult:" + mult);
        System.out.println("resto:" + resto);
    } //fim da main1
    
}//fim do classe
