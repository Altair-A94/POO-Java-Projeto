
package ativade.verificadora.de.aprendizagem;

public class AtivadeVerificadoraDeAprendizagem {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
