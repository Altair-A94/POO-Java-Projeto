
package ativade.verificadora.de.aprendizagem;

import java.util.Date;


public class Conta_Bancaria {
    
private double saldo;
private Date dateAbertura;

    public Conta_Bancaria(double saldo, Date dateAbertura) {
        this.saldo = saldo;
        this.dateAbertura = dateAbertura;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public Date getDateAbertura() {
        return dateAbertura;
    }
    








}
