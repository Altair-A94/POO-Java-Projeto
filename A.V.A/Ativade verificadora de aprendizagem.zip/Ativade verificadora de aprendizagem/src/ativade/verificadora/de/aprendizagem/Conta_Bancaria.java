
package ativade.verificadora.de.aprendizagem;

import java.util.Date;


public class Conta_Bancaria {
    
private double saldo;
private Date dateAbertura;

    public Conta_Bancaria(double saldo, Date dateAbertura) {
        this.saldo = saldo;
        this.dateAbertura = dateAbertura;
    }
    








}
